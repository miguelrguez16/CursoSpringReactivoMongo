package es.java.eureka.eurekaspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
