package com.example.springApiRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
