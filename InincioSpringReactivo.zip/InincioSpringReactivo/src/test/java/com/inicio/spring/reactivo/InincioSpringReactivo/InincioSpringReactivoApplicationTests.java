package com.inicio.spring.reactivo.InincioSpringReactivo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InincioSpringReactivoApplicationTests {

	@Test
	void contextLoads() {
	}

}
