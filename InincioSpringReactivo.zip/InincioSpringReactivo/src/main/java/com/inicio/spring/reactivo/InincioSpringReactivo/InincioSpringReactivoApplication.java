package com.inicio.spring.reactivo.InincioSpringReactivo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InincioSpringReactivoApplication {

	public static void main(String[] args) {
		SpringApplication.run(InincioSpringReactivoApplication.class, args);
	}

}
